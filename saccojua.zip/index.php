<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=views/index.php">
<title>Rep Sacco</title>
<script language="javascript">
    window.location.href = "views/index.php"
</script>
</head>
<body>
Go to <a href="views/index.php">/views/index.php</a>
</body>
</html>
