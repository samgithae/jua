<?php
/**
 * Created by PhpStorm.
 * User: New LAptop
 * Date: 27/04/2017
 * Time: 06:46
 */
?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width",initial-scale="1.0">
<title> Rep sacco</title>
<link href= "public/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="public/assets/css/custom.css " rel="stylesheet">
<script src="public/assets/js/respond.js"></script>
<script src="public/assets/js/custom.js"></script>

